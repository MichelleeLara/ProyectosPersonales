package com.univdep;

public class Main {

    public static void main(String[] args) {

        (new Choice()).go();

    }
}
