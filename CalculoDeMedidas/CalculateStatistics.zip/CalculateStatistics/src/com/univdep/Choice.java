package com.univdep;

import java.io.*;
import java.util.Arrays;

public class Choice {

    public void go(){
        dataEntry A = new dataEntry("C:/temp/datos.txt");

        if (A.Existe()){

            File archivo;
            try {
                archivo = new File("C:\\temp\\lop .txt");
                if (archivo.createNewFile()) {
                    File f;
                    FileWriter w ;
                    BufferedWriter bw;
                    PrintWriter wr;

                    f = new File (String.valueOf(archivo));
                    w = new FileWriter(f);
                    bw = new BufferedWriter(w);
                    wr = new PrintWriter(bw);

                    wr.write("Pinche RAY :)");

                    wr.close();
                    bw.close();

                    System.out.println("se ha creado el archivo con exito");
                }
            }catch (IOException e){
                System.err.println("No se pudo crear nada  " + e);
            }

            A.LeeContenido();

            if (A.getContenido().isEmpty()){
                System.err.println("Advertencia. El archivo no tiene contenido.");
            }else {
                //String rem = A.getContenido().replace(" " ,"");
                //String[] guar = rem.split("\\|");
                //System.out.println("Los datos a utilizar son " + Arrays.toString(guar) + "     " + guar.length);
                System.out.println(A.getContenido());

                //System.out.println("TAMAÑO DEL ARREGLO FINAL : "+ guar.length);
            }
        }else
            System.err.println("Error. El archivo solictado no existe.");




        String validar = A.getContenido().replace(" " , "");
        String validar11 = validar.replace("\n" , " ");
        System.out.println("validar 11 : " + validar11);
        String pf = validar11.replace(" " , "|");
        System.out.println("Esto es pf: " + pf);
        String [] validar1 = pf.split("\\|");

        System.out.println("datos para validar : " + Arrays.toString(validar1));
        System.out.println("tamaño : " + validar1.length);
        int contador =0 ;
        for (int x = 0 ; x< validar1.length ; x++){
            contador++;
        }
        System.out.println("cantidad : " + contador);
    }


}
