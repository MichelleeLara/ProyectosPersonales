package students;

public class Pantalladecarga {

    public static void main(String[] args) {
        new Carga().setVisible(true);
    }
   
}
